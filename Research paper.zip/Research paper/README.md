# Research Paper: Edge-Optimized Spectral Masking

## Building the PDF

### Prerequisites
```bash
# Ubuntu/Debian
sudo apt install texlive-full

# OR minimal install
sudo apt install texlive-latex-base texlive-latex-recommended \
                 texlive-latex-extra texlive-fonts-recommended \
                 texlive-bibtex-extra biber
```

### Build
```bash
cd "Research paper"
make
```

Or manually:
```bash
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

### View
```bash
make view
```

## File Structure
```
Research paper/
├── main.tex          ← Full paper (IEEE template)
├── references.bib    ← Bibliography (40+ references)
├── Makefile           ← Build automation
├── figures/           ← Paper figures (to be added)
│   └── .gitkeep
└── README.md          ← This file
```

## TODO Before Submission
- [ ] Add author name and affiliation in main.tex
- [ ] Generate system architecture diagram → figures/system_architecture.pdf
- [ ] Generate lifecycle FSM diagram → figures/lifecycle_fsm.pdf
- [ ] Generate confusion matrix plot → figures/confusion_matrix.pdf
- [ ] Run actual experiments on Pi 4B hardware and update Table IV–VIII values
- [ ] Download IEEEtran.cls if not in your LaTeX distribution
- [ ] Final proofread and formatting check
